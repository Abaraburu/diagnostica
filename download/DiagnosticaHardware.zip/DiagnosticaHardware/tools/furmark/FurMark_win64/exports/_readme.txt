Folder for data export.
